<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\User;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
           //get all
           return User::all();
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            // create one user
          // 1 verify and validate incomming data
          $feilds = $request->validate(
            [
                'name'=>'required|string',
                'email'=>'required|string|unique:users,email',
                'password' => 'required|string|confirmed',
                'role' => 'in:admin ,financial, commercial',

            ]);


            $feilds = array_merge($feilds, ['role' => $feilds['role'] ?? 'admin']);


            // 2 create user from data
            $user = User::create(
                [
                    'name'=> $feilds['name'],
                    'email'=>$feilds['email'],
                    'password' => bcrypt($feilds['password']),
                    'role' => $feilds['role']
                ]
                );

        // 3 create token from user data for that specific user

        $response = [
            'user'=>$user,
        ];

        // 4 send back the response information
        return Response($response,200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // get one
        $user = User::find($id);

        return [
            "user"=>$user,
            "message"=>$user?"":"no user found",
            "status"=>"success"
        ];
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //update
        // 1 get the product first
        $user =  User::find($id);

        // 2 update the product
        $user->update($request->all());

        return $user;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //delete
        $user =  User::where('id',$id)->update(['status'=>'blocked']);
        return Response(json_encode($user),200);
    }

    public function count(){
		$numUsers = User::count();
        return $numUsers?$numUsers:0;
    }
}
