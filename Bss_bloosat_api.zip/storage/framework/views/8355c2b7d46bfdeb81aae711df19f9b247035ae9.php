<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h4>Cher Mr/Mme <?php echo e($email_data['bill']['customerName']); ?></h4>
    <p><?php echo e($email_data['message']); ?>,presenter vous pour regler votre facture de reference : <?php echo e($email_data['bill']['billNumber']); ?>,
        pour ne pas etre suspendu</p>
</body>
</html><?php /**PATH C:\Users\Gildas Gamaliel\Desktop\BLOOSAT\Bss_bloosat_api\resources\views/email.blade.php ENDPATH**/ ?>