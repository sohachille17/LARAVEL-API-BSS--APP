<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h4>Cher Client {{$email_data['bill']['customerName']}}</h4>
    <p>{{$email_data['message']}} <br/> Presenter vous pour regler votre facture et ne pas etre suspendu.
        Pour obtenir votre facture visiter le lient suivant : <a href=`https://ssobloosat.com/v3/mail_reciept?id={{$email_data['bill']['id']}}`>voir ma facture</a></p>
</body>
</html>
