<?php


use Illuminate\Database\Seeder;
use App\model\Customer;
use Illuminate\Support\Facades\DB;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //$faker = Faker\Factory::create();

        //creating dummy content;
       // for($i = 0; $i < 50; $i++){
           
           

       // }
        
    }
}
