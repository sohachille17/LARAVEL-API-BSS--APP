<?php


use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\BillController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\productQuantitiesController;
use App\Http\Controllers\ServicesController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\SouscriptionController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SubscriptionController;

use App\User;


/*
|--------------------------------------------------------------------------
 AUTH API ROUTES [ Register , Login , logout]
|--------------------------------------------------------------------------
*/

Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);

Route::group(['middleware'=>['auth:sanctum']],function () {
  // Private route for user
  Route::post('/logout',[AuthController::class, 'logout']);
  Route::post('/reset-password/{userId}',[AuthController::class, 'resetPassword']);

  // Route::get('/allBills', [BillController::class, 'getAllBill'])->middleware('restrictRole:cashier');
});






/*
|--------------------------------------------------------------------------
 USERS API ROUTES
|--------------------------------------------------------------------------
*/

Route::group(['middleware'=>['auth:sanctum']],function () {

  Route::get('users/count',[UserController::class, 'count']);
  Route::resource('users','UserController');

});









/*
|--------------------------------------------------------------------------
 Subscriptions API ROUTES
|--------------------------------------------------------------------------
*/

Route::get('subscriptions/update-expired-subscriptions',[SubscriptionController::class, 'check_and_end_ongoing_subscription_if_expired']);
Route::get('subscriptions/update-royalty-subscriptions',[SubscriptionController::class, 'check_and_set_royalty_subscription_to_ongoin']);
Route::get('subscriptions/check-unpaid-ongoing-and-suspend-kaf',[SubscriptionController::class, 'check_unpaid_ongoing_kaf_subscription_and_suspend']);
Route::get('subscriptions/check-unpaid-ongoing-and-suspend-iway',[SubscriptionController::class, 'check_unpaid_ongoing_iway_subscription_and_suspend']);

Route::get('subscriptions/renew-next-subscriptions-kaf',[SubscriptionController::class, 'create_new_next_subscriptions_version_kaf']);
Route::get('subscriptions/renew-next-subscriptions-iway',[SubscriptionController::class, 'create_new_next_subscriptions_version_iway']);
Route::get('subscriptions/renew-next-subscriptions-bluestar',[SubscriptionController::class, 'create_new_next_subscriptions_version_bluestar']);

Route::get('subscriptions/soon-ending',[SubscriptionController::class, 'get_soon_ending_subscriptions']);
Route::get('subscriptions/customer/{customerId}',[SubscriptionController::class, 'showCustomerSubscriptions']);


Route::group(['middleware'=>['auth:sanctum']],function () {

  Route::resource('subscriptions','SubscriptionController')->middleware('restrictRole:admin,financial');

});

/*
|--------------------------------------------------------------------------
 Services API ROUTES
|--------------------------------------------------------------------------
*/

Route::group(['middleware'=>['auth:sanctum']],function () {

  Route::get('services/products-and-services',[ServicesController::class,'getAllTypes'])->middleware('restrictRole:admin,financial');
  Route::get('services/count-all-services',[ServicesController::class,'countServices']);
  Route::get('services/count-all-products',[ServicesController::class,'countProducts']);
  Route::resource('services','ServicesController');

});


/*
|--------------------------------------------------------------------------
 PAYMENTS API ROUTES
|--------------------------------------------------------------------------
*/

Route::group(['middleware'=>['auth:sanctum']],function () {

  Route::get('/payments/customer/{customerId}',[PaymentController::class, 'showCustomerPayments'])->middleware('restrictRole:admin,financial');
  Route::resource('payments','PaymentController')->middleware('restrictRole:admin,financial');

});



/*
|--------------------------------------------------------------------------
 BILL --VALIDATED API--
|--------------------------------------------------------------------------
*/

Route::get('/allBills', [BillController::class, 'getAllBill']);
Route::post('bills/create', [BillController::class, 'createBill']);
Route::get('bill/{id}', [BillController::class, 'getOneBill']);
Route::get('bill/edit/{id}', [BillController::class, 'edit']);
Route::get('bill/delete/{id}', [BillController::class, 'deleteInv']);
Route::get('billCount', [BillController::class, 'getTotalBill']);
Route::get('bill/show_bill/{id}', [BillController::class, 'show_billing']);
Route::post('bill/update/{id}', [BillController::class, 'update__billing']);
Route::get('bill/details/{id}', [productQuantitiesController::class,'getItemsById']);
Route::get('bill/customers/{id}', [BillController::class, 'getCustomerBillById']);

// Special care should be given to the next route
Route::delete('bill/delete/{id}',[productQuantitiesController::class, 'deleteBill']);








/*
|--------------------------------------------------------------------------
 CATEGORY --VALIDATED API--
|--------------------------------------------------------------------------
*/


Route::post('category/create', [CategoryController::class, 'createCategory']);
Route::get('category', [CategoryController::class, 'getAllCategory']);
Route::get('category/{id}', [CategoryController::class,'getCategoryId']);
Route::put('category/update/{id}',[CategoryController::class, 'updateCategory']);
Route::get('category/delete/{id}',[CategoryController::class, 'deleteCategory']);


/*
|--------------------------------------------------------------------------
 PRODUCT --VALIDATED API--
|--------------------------------------------------------------------------
*/


Route::post('product/create', [ProductController::class, 'addProduct']);
Route::get('product', [ProductController::class, 'getAllProduct']);
Route::get('product/{id}', [ProductController::class, 'getProductById']);
Route::get('product/delete/{id}', [ProductController::class, 'deleteService']);
Route::put('product/update/{id}', [ProductController::class, 'updateProduct']);
//Route::get('product/count', [ProductController, 'getProductCount']);

  /*
  |--------------------------------------------------------------------------
  CUSTOMERS --VALIDATED API--
  |--------------------------------------------------------------------------
  */

  Route::get('customers',[CustomerController::class,'getAll']);
  Route::put('customers/status/{id}', [CustomerController::class, 'statusUpdate']);
  Route::get('customers/{id}',[CustomerController::class,'getOne']);
  Route::post('customers/create', [CustomerController::class,'create']);
  Route::put('customers/update/{id}', [CustomerController::class,'updateCustomer']);
  Route::delete('customers/delete/{id}', [CustomerController::class,'deleteCustomers']);
  Route::get('customersCount', [CustomerController::class, 'getTotalCustomersCount']);



  // Route::get('findUser', [AuthenticationController::class, 'getAllUsers']);




